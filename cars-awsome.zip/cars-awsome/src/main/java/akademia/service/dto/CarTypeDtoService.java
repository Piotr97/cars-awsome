package akademia.service.dto;

import akademia.mapper.CarTypeDtoMapper;
import akademia.model.CarType;
import akademia.model.dto.CarTypeDto;
import akademia.repository.CarTypeRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class CarTypeDtoService {

    private CarTypeRepository carTypeRepository;
    private CarTypeDtoMapper carTypeDtoMapper;

    public CarTypeDtoService(CarTypeRepository carTypeRepository, CarTypeDtoMapper carTypeDtoMapper) {
        this.carTypeRepository = carTypeRepository;
        this.carTypeDtoMapper = carTypeDtoMapper;
    }

    public List<CarTypeDto> getCarTypes() {
        List<CarTypeDto> carTypeDtos = new ArrayList<>();
        carTypeRepository
                .findAll()
                .forEach(t -> carTypeDtos.add(carTypeDtoMapper.map(t)));
        return carTypeDtos;
    }
}
