package akademia.model.users;

public enum Gender {
    MALE, FEMALE;
}
